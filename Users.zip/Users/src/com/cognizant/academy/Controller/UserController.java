package com.cognizant.academy.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.academy.Model.User;
import com.cognizant.academy.Service.UserBO;

@Controller
public class UserController {
	
	@RequestMapping(value="/displayRegistrationForm", method = RequestMethod.GET)
	public ModelAndView displayRegistrationForm()
	{
		System.out.println("test");
		return new ModelAndView("UserRegistration","command",new User());
	}
	
	@RequestMapping(value="/registerUser", method=RequestMethod.POST)
	public String registerTeacher(HttpServletRequest request)
	{
		String name=request.getParameter("name");
		String role=request.getParameter("role");
		String username=request.getParameter("uname");
		String password=request.getParameter("pwd");
		User user=new User();
		user.setName(name);
		user.setPassword(password);
		user.setRole(role);
		user.setStatus("inactive");
		user.setUsername(username);
		
		UserBO userbo=new UserBO();
		
		userbo.registerUser(user);
		return "redirect:/UserLogin";
	}

}
