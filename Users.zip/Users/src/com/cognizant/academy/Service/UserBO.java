package com.cognizant.academy.Service;

import com.cognizant.academy.Dao.UserDao;
import com.cognizant.academy.Model.User;

public class UserBO {

	public void registerUser(User user) {
		UserDao userdao=new UserDao();
		userdao.registerUser(user);
	}

}
