package com.cognizant.academy.Dao;

import org.springframework.transaction.annotation.Transactional;

import com.cognizant.academy.Model.User;

public class UserDao {

	@Transactional
	public void registerUser(User user) {
		
		
	}

}
